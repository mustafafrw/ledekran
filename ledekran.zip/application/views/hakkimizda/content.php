<section class="blog-details spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="blog-details-inner">
                        <div class="blog-detail-title">
                            <h2>Hakkımızda</h2>
                        </div>

                        <div class="blog-detail-desc">
                            <p>
                            <?php echo $items["ayarlar"]->hakkimda; ?>
                            </p>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>