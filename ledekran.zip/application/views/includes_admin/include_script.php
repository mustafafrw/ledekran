<!-- build:js /assets/js/core.min.js -->
<script src="<?php echo base_url("includes/admin"); ?>/libs/bower/jquery/dist/jquery.js"></script>
<script src="<?php echo base_url("includes/admin"); ?>/libs/bower/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url("includes/admin"); ?>/libs/bower/jQuery-Storage-API/jquery.storageapi.min.js"></script>
<script src="<?php echo base_url("includes/admin"); ?>/libs/bower/bootstrap-sass/assets/javascripts/bootstrap.js"></script>
<script src="<?php echo base_url("includes/admin"); ?>/libs/bower/jquery-slimscroll/jquery.slimscroll.js"></script>
<script src="<?php echo base_url("includes/admin"); ?>/libs/bower/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>
<script src="<?php echo base_url("includes/admin"); ?>/libs/bower/PACE/pace.min.js"></script>
<!-- endbuild -->

<!-- build:js <?php echo base_url("includes/admin"); ?>/assets/js/app.min.js -->
<!--<script src="--><?php //echo base_url("assets"); ?><!--/assets/js/library.js"></script>-->
<?php $this->load->view("includes_admin/library"); ?>
<script src="<?php echo base_url("includes/admin"); ?>/assets/js/plugins.js"></script>
<script src="<?php echo base_url("includes/admin"); ?>/assets/js/app.js"></script>
<!-- endbuild -->
<script src="<?php echo base_url("includes/admin"); ?>/libs/bower/moment/moment.js"></script>
<script src="<?php echo base_url("includes/admin"); ?>/libs/bower/fullcalendar/dist/fullcalendar.min.js"></script>
<script src="<?php echo base_url("includes/admin"); ?>/assets/js/fullcalendar.js"></script>

<script src="<?php echo base_url("includes/admin"); ?>/assets/js/sweetalert2.all.js"></script>

<!--<script src="<?php echo base_url("includes/admin"); ?>/assets/js/custom.js"></script>-->
