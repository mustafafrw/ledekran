
    <script src="<?php echo base_url("includes"); ?>/js/jquery-3.3.1.min.js"></script>
    <script src="<?php echo base_url("includes"); ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url("includes"); ?>/js/jquery-ui.min.js"></script>
    <script src="<?php echo base_url("includes"); ?>/js/jquery.countdown.min.js"></script>
    <script src="<?php echo base_url("includes"); ?>/js/jquery.nice-select.min.js"></script>
    <script src="<?php echo base_url("includes"); ?>/js/jquery.zoom.min.js"></script>
    <script src="<?php echo base_url("includes"); ?>/js/jquery.dd.min.js"></script>
    <script src="<?php echo base_url("includes"); ?>/js/jquery.slicknav.js"></script>
    <script src="<?php echo base_url("includes"); ?>/js/owl.carousel.min.js"></script>
    <script src="<?php echo base_url("includes"); ?>/js/main.js"></script>
