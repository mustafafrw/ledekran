    <link rel="stylesheet" href="<?php echo base_url("includes"); ?>/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url("includes"); ?>/css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url("includes"); ?>/css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url("includes"); ?>/css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url("includes"); ?>/css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url("includes"); ?>/css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url("includes"); ?>/css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url("includes"); ?>/css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url("includes"); ?>/css/style.css" type="text/css">
       
